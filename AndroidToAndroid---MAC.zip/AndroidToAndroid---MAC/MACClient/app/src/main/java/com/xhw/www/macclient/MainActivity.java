package com.xhw.www.macclient;

import java.io.BufferedReader;

import java.io.InputStreamReader;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import android.content.pm.PackageManager;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.Reader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    public static TextView mTextView, textView1;


    private static String serverIP;
    private static String localMAC;

    private static ProgressDialog searchDialog;

    private static Button bt_sendMac;
    private static EditText et_serverIP;
    private static EditText et_localMAC;

    private TcpSocketConnect socketConnect;
    private Handler handler;
    private boolean serverConnect = false;

    private static String IP = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = (TextView) findViewById(R.id.textsss);
        mTextView.setMovementMethod(ScrollingMovementMethod.getInstance());
        textView1 = (TextView) findViewById(R.id.textView1);

        bt_sendMac = (Button) findViewById(R.id.bt_sendMac);

        et_localMAC = (EditText) findViewById(R.id.et_localMAC);
        et_serverIP = (EditText) findViewById(R.id.et_serverIP);

        setButtonListener();

        IP = getlocalip();
        et_serverIP.setText("192.168.199.120");
        textView1.setText("local addresss:" + IP);
        et_localMAC.setText(getMac(MainActivity.this));



        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 1:
                        //get  time
                        DateFormat df = new SimpleDateFormat("HH:mm:ss");
                        mTextView.append(df.format(new Date()) +"---"+"sever"+"---"+msg.obj.toString().substring(0).replace("/n","").replace("\n","")+"\n");


                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        searchDialog.dismiss();

                        int result = Integer.valueOf(msg.obj.toString().substring(0).replace("/n","").replace("\n",""));

                        switch (result) {
                            case 0:
                                builder.setTitle(R.string.mac_activity_title).setMessage("0")
                                        .setPositiveButton(R.string.mac_activity_sure, new DialogInterface.OnClickListener() {
                                            // 点击确定按钮
                                            public void onClick(DialogInterface dialog, int which) {
                                            }
                                        }).show();
                                break;


                            case 1:
                                builder.setTitle(R.string.mac_activity_title).setMessage("1")
                                        .setPositiveButton(R.string.mac_activity_sure, new DialogInterface.OnClickListener() {
                                            // 点击确定按钮
                                            public void onClick(DialogInterface dialog, int which) {
                                                ////////////////
                                            }
                                        }).show();
                                break;
                        }




                        break;

                    default:
                        break;
                }
                super.handleMessage(msg);
            }
        };
//        socketConnect = new TcpSocketConnect(callback, serverIP, 20000);
//        new Thread(socketConnect).start();
    }
    /**
     * 添加监听器
     */
    private void setButtonListener() {

        bt_sendMac.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                serverIP = et_serverIP.getText().toString();
                localMAC = et_localMAC.getText().toString();
                if(!isIP(serverIP)){
                    new AlertDialog.Builder(MainActivity.this).setTitle(R.string.mac_activity_title)
                            .setMessage(R.string.mac_server_null)
                            .setPositiveButton(R.string.mac_activity_sure, new DialogInterface.OnClickListener() {
                                // 点击确定按钮
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            }).show();
                    return;
                }

                if ("".equals(localMAC)) {
                    new AlertDialog.Builder(MainActivity.this).setTitle(R.string.mac_activity_title)
                            .setMessage(R.string.mac_address_null)
                            .setPositiveButton(R.string.mac_activity_sure, new DialogInterface.OnClickListener() {
                                // 点击确定按钮
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            }).show();
                    return;
                }

                // 显示对话框
                searchDialog = new ProgressDialog(MainActivity.this);
                searchDialog.setTitle(R.string.mac_activity_title);
                searchDialog.setMessage("Waiting...");
                searchDialog.setCancelable(false);
                searchDialog.setIndeterminate(true);
                searchDialog.show();

                String msg = localMAC;

                if(!TextUtils.isEmpty(serverIP)){
                    socketConnect = new TcpSocketConnect(callback, serverIP, 20000);
                    new Thread(socketConnect).start();
                }
                while(!serverConnect){
                    Toast.makeText(MainActivity.this, "waiting...", Toast.LENGTH_SHORT).show();
                }
                if (!TextUtils.isEmpty(msg) && serverConnect) {
                    socketConnect.sendButCmd(msg.getBytes());
                }
            }

        });
    }

    public boolean isIP(String addr){

        if(addr.length() < 7 || addr.length() > 15 || "".equals(addr))
        {
            return false;
        }
        if(addr.equals("127.0.0.1"))
        {
            return true;
        }
        if(addr.equals("localhost"))
        {
            return true;
        }
        /**
         * 判断IP格式和范围
         */
        String rexp = "([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])(\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])){3}";
        Pattern pat = Pattern.compile(rexp);
        Matcher mat = pat.matcher(addr);
        boolean ipAddress = ((Matcher) mat).find();
        //============对之前的ip判断的bug在进行判断
        if (ipAddress==true){
            String ips[] = addr.split("\\.");
            if(ips.length==4){
                try{
                    for(String ip : ips){
                        if(Integer.parseInt(ip)<0||Integer.parseInt(ip)>255){
                            return false;
                        }
                    }
                }catch (Exception e){
                    return false;
                }
                return true;
            }else{
                return false;
            }
        }
        return ipAddress;
    }


    private String getlocalip() {
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);//getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ipAddress = wifiInfo.getIpAddress();
        //  Log.d(Tag, "int ip "+ipAddress);
        if (ipAddress == 0) return "127.0.0.1";
        return ((ipAddress & 0xff) + "." + (ipAddress >> 8 & 0xff) + "."
                + (ipAddress >> 16 & 0xff) + "." + (ipAddress >> 24 & 0xff));
    }

    public static String getMac(Context context) {

        String strMac = null;

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            Log.e("=====", "under6.0");
            Toast.makeText(context, "under6.0", Toast.LENGTH_SHORT).show();
            strMac = getLocalMacAddressFromWifiInfo(context);
            return strMac;
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N
                && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.e("=====", "over6.0under7.0");
            Toast.makeText(context, "over6.0under7.0", Toast.LENGTH_SHORT).show();
            strMac = getMacAddress(context);
            return strMac;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Log.e("=====", "over7.0");
            if (!TextUtils.isEmpty(getMacAddress())) {
                Log.e("=====", "over7.0 1");
                Toast.makeText(context, "over7.0 1", Toast.LENGTH_SHORT).show();
                strMac = getMacAddress();
                return strMac;
            } else if (!TextUtils.isEmpty(getMachineHardwareAddress())) {
                Log.e("=====", "over7.0 2");
                Toast.makeText(context, "over7.0 2", Toast.LENGTH_SHORT).show();
                strMac = getMachineHardwareAddress();
                return strMac;
            } else {
                Log.e("=====", "over7.0 3");
                Toast.makeText(context, "over7.0 3", Toast.LENGTH_SHORT).show();
                strMac = getLocalMacAddressFromBusybox();
                return strMac;
            }
        }

        return "02:00:00:00:00:00";
    }
    //根据Wifi信息获取本地Mac
    public static String getLocalMacAddressFromWifiInfo(Context context){
        WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi.getConnectionInfo();
        return info.getMacAddress();
    }
    /**
     * android 6.0及以上、7.0以下 获取mac地址
     *
     * @param context
     * @return
     */
    public static String getMacAddress(Context context) {

        // 如果是6.0以下，直接通过wifimanager获取
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            String macAddress0 = getMacAddress0(context);
            if (!TextUtils.isEmpty(macAddress0)) {
                return macAddress0;
            }
        }
        String str = "";
        String macSerial = "";
        try {
            Process pp = Runtime.getRuntime().exec(
                    "cat /sys/class/net/wlan0/address");
            InputStreamReader ir = new InputStreamReader(pp.getInputStream());
            LineNumberReader input = new LineNumberReader(ir);
            for (; null != str; ) {
                str = input.readLine();
                if (str != null) {
                    macSerial = str.trim();// 去空格
                    break;
                }
            }
        } catch (Exception ex) {
            Log.e("----->" + "NetInfoManager", "getMacAddress:" + ex.toString());
        }
        if (macSerial == null || "".equals(macSerial)) {
            try {
                return loadFileAsString("/sys/class/net/eth0/address")
                        .toUpperCase().substring(0, 17);
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("----->" + "NetInfoManager",
                        "getMacAddress:" + e.toString());
            }

        }
        return macSerial;
    }

    private static String getMacAddress0(Context context) {
        if (isAccessWifiStateAuthorized(context)) {
            WifiManager wifiMgr = (WifiManager) context
                    .getSystemService(Context.WIFI_SERVICE);
            WifiInfo wifiInfo = null;
            try {
                wifiInfo = wifiMgr.getConnectionInfo();
                return wifiInfo.getMacAddress();
            } catch (Exception e) {
                Log.e("----->" + "NetInfoManager",
                        "getMacAddress0:" + e.toString());
            }

        }
        return "";

    }

    /**
     * Check whether accessing wifi state is permitted
     *
     * @param context
     * @return
     */
    private static boolean isAccessWifiStateAuthorized(Context context) {
        if (PackageManager.PERMISSION_GRANTED == context
                .checkCallingOrSelfPermission("android.permission.ACCESS_WIFI_STATE")) {
            Log.e("----->" + "NetInfoManager", "isAccessWifiStateAuthorized:"
                    + "access wifi state is enabled");
            return true;
        } else
            return false;
    }

    private static String loadFileAsString(String fileName) throws Exception {
        FileReader reader = new FileReader(fileName);
        String text = loadReaderAsString(reader);
        reader.close();
        return text;
    }

    private static String loadReaderAsString(Reader reader) throws Exception {
        StringBuilder builder = new StringBuilder();
        char[] buffer = new char[4096];
        int readLength = reader.read(buffer);
        while (readLength >= 0) {
            builder.append(buffer, 0, readLength);
            readLength = reader.read(buffer);
        }
        return builder.toString();
    }

    /**
     * 根据IP地址获取MAC地址
     *
     * @return
     */
    public static String getMacAddress() {
        String strMacAddr = null;
        try {
            // 获得IpD地址
            InetAddress ip = getLocalInetAddress();
            byte[] b = NetworkInterface.getByInetAddress(ip)
                    .getHardwareAddress();
            StringBuffer buffer = new StringBuffer();
            for (int i = 0; i < b.length; i++) {
                if (i != 0) {
                    buffer.append(':');
                }
                String str = Integer.toHexString(b[i] & 0xFF);
                buffer.append(str.length() == 1 ? 0 + str : str);
            }
            strMacAddr = buffer.toString().toUpperCase();
        } catch (Exception e) {
        }
        return strMacAddr;
    }
    /**
     * 获取移动设备本地IP
     *
     * @return
     */
    private static InetAddress getLocalInetAddress() {
        InetAddress ip = null;
        try {
            // 列举
            Enumeration<NetworkInterface> en_netInterface = NetworkInterface
                    .getNetworkInterfaces();
            while (en_netInterface.hasMoreElements()) {// 是否还有元素
                NetworkInterface ni = (NetworkInterface) en_netInterface
                        .nextElement();// 得到下一个元素
                Enumeration<InetAddress> en_ip = ni.getInetAddresses();// 得到一个ip地址的列举
                while (en_ip.hasMoreElements()) {
                    ip = en_ip.nextElement();
                    if (!ip.isLoopbackAddress()
                            && ip.getHostAddress().indexOf(":") == -1)
                        break;
                    else
                        ip = null;
                }

                if (ip != null) {
                    break;
                }
            }
        } catch (SocketException e) {

            e.printStackTrace();
        }
        return ip;
    }

    /**
     * 获取本地IP
     *
     * @return
     */
    private static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface
                    .getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf
                        .getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    /**
     * android 7.0及以上 （2）扫描各个网络接口获取mac地址
     *
     */
    /**
     * 获取设备HardwareAddress地址
     *
     * @return
     */
    public static String getMachineHardwareAddress() {
        Enumeration<NetworkInterface> interfaces = null;
        try {
            interfaces = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException e) {
            e.printStackTrace();
        }
        String hardWareAddress = null;
        NetworkInterface iF = null;
        if (interfaces == null) {
            return null;
        }
        while (interfaces.hasMoreElements()) {
            iF = interfaces.nextElement();
            try {
                hardWareAddress = bytesToString(iF.getHardwareAddress());
                if (hardWareAddress != null)
                    break;
            } catch (SocketException e) {
                e.printStackTrace();
            }
        }
        return hardWareAddress;
    }

    /***
     * byte转为String
     *
     * @param bytes
     * @return
     */
    private static String bytesToString(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        StringBuilder buf = new StringBuilder();
        for (byte b : bytes) {
            buf.append(String.format("%02X:", b));
        }
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
        }
        return buf.toString();
    }

    /**
     * android 7.0及以上 （3）通过busybox获取本地存储的mac地址
     *
     */

    /**
     * 根据busybox获取本地Mac
     *
     * @return
     */
    public static String getLocalMacAddressFromBusybox() {
        String result = "";
        String Mac = "";
        result = callCmd("busybox ifconfig", "HWaddr");
        // 如果返回的result == null，则说明网络不可取
        if (result == null) {
            return "net error";
        }
        // 对该行数据进行解析
        // 例如：eth0 Link encap:Ethernet HWaddr 00:16:E8:3E:DF:67
        if (result.length() > 0 && result.contains("HWaddr") == true) {
            Mac = result.substring(result.indexOf("HWaddr") + 6,
                    result.length() - 1);
            result = Mac;
        }
        return result;
    }

    private static String callCmd(String cmd, String filter) {
        String result = "";
        String line = "";
        try {
            Process proc = Runtime.getRuntime().exec(cmd);
            InputStreamReader is = new InputStreamReader(proc.getInputStream());
            BufferedReader br = new BufferedReader(is);

            while ((line = br.readLine()) != null
                    && line.contains(filter) == false) {
                result += line;
            }

            result = line;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    TcpSocketCallback callback = new TcpSocketCallback() {

        @Override
        public void tcp_receive(byte[] buffer) {
            Message msg = new Message();
            msg.what = 1;
            msg.obj = new String(buffer);

            handler.sendMessage(msg);
        }

        @Override
        public void tcp_disconnect() {
            // TODO Auto-generated method stub
            serverConnect = false;
        }

        @Override
        public void tcp_connected() {
            // TODO Auto-generated method stub
            serverConnect = true;
        }
    };

    @Override
    protected void onResume() {
        if(!TextUtils.isEmpty(serverIP)){
            socketConnect = new TcpSocketConnect(callback, serverIP, 20000);
            new Thread(socketConnect).start();
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        if (socketConnect != null) {
            socketConnect.disconnect();
        }
        super.onPause();
    }
}
