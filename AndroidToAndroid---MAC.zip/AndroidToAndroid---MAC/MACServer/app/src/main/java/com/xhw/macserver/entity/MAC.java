package com.xhw.macserver.entity;

/**
 * Created by lenovo on 2018/10/14.
 */

public class MAC {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    private String mac;

}
