package com.xhw.macserver.dbutil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.xhw.macserver.entity.MAC;

import java.util.ArrayList;
import java.util.List;


public class UtilDao {
    private DatabaseUtil du;
    private SQLiteDatabase db;

    public UtilDao(Context context){
        du = new DatabaseUtil(context);
        db = du.getWritableDatabase();
    }


    /**
     * 添加数据
     * */
    public int addData(String tableName,String[] key,String[] values){
        ContentValues contentValues = new ContentValues();
        for(int i = 0; i < key.length; i ++){
            contentValues.put(key[i],values[i]);
        }
        try{
        db.insert(tableName,null,contentValues);
        contentValues.clear();
        return 1;
        }catch(Exception e){
            return 0;
        }
    }

    /**
     * 删除数据
     * */
    public int delData(String where,String[] values){
        int del_data;
        del_data = db.delete("MACInfo",where,values);
        return del_data;
    }

    /**
     * 修改数据
     * */
    public void update(String[] values){
        db.execSQL("update MACInfo set name=?,mac=? where mac=? ",values);
    }

    /**
     * 查询数据
     * */
    public List<MAC> inquireData(){
        List<MAC> list = new ArrayList<>();
        Cursor cursor = db.rawQuery("select name,mac" +
                " from MACInfo",null);
            while(cursor.moveToNext()){
                String name = cursor.getString(0);
                String macstr = cursor.getString(1);

                MAC mac = new MAC();
                mac.setName(name);
                mac.setMac(macstr);

                list.add(mac);
            }

        return list;
    }

    /**
     * 查询数据Mac
     * */
    public int selectMac(String mac) {

        Cursor cursor = db.query("MACInfo", new String[]{"name", "mac"}, "mac = ?", new String[]{mac}, null, null, "id desc");
        //判断结果集是否有效
        if (cursor != null && cursor.getCount() > 0) {
            return 1;
        }
        return 0;
    }

    /**
     * 关闭数据库连接
     * */
    public void getClose(){
        if(db != null){
            db.close();
        }
    }
}
